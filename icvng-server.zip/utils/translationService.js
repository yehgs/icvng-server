/**
 * utils/translationService.js
 *
 * Auto-translation pipeline powered by OpenAI (see
 * services/ai/openaiTranslationClient.js for the actual API calls, prompts,
 * and retry logic — this file is the business logic layer on top of it:
 * which fields to translate per entity, the "don't clobber manual edits"
 * guard, and reading translations back out for the storefront/admin).
 *
 * Requires OPENAI_API_KEY to be set server-side (see openaiTranslationClient
 * for details). Never hardcode the key, never expose it to the frontend.
 *
 * The admin panel triggers translateEntity() after saving any content.
 * The client reads from the Translation collection via getTranslation().
 */

import TranslationModel from "../models/translation.model.js";
import { ALL_SUPPORTED_LANGUAGES } from "../config/countries/index.js";
import {
  translateBatchAI,
  translateOneAI,
} from "../services/ai/openaiTranslationClient.js";

// ── Config ───────────────────────────────────────────────────────────────────

// Driven by country config (same source of truth the Translation model
// uses) rather than a frozen list — a new market/language needs no edit
// here.
const SUPPORTED_LANGUAGES = ALL_SUPPORTED_LANGUAGES.length
  ? ALL_SUPPORTED_LANGUAGES
  : ["en", "fr", "it"];

if (!process.env.OPENAI_API_KEY) {
  console.warn(
    "[translationService] OPENAI_API_KEY is not set — AI auto-translation " +
      "will fail at request time (translations fall back to source text). " +
      "Set OPENAI_API_KEY in the server environment to enable it. " +
      "Manual translations (admin-entered) are unaffected."
  );
}

// Fields to translate per entity type  (source language is always "en")
// NOTE: field paths must match the actual Mongoose schema shape. Products
// and blog posts store `seoTitle`/`seoDescription` as flat top-level
// fields (not a nested `seo: { title, description }` object) — using
// "seo.title" here silently matched nothing, so SEO copy was never
// auto-translated. Fixed to the real flat field names below.
const TRANSLATABLE_FIELDS = {
  product: ["name", "description", "unit", "seoTitle", "seoDescription", "roastOrigin", "coffeeOrigin", "blend", "shortDescription", "additionalInfo"],
  category: ["name"],
  subCategory: ["name"],
  brand: ["name"],
  blog: ["title", "content", "excerpt", "seoTitle", "seoDescription", "seoKeywords", "socialTitle"],
  blogCategory: ["name", "description", "seoTitle", "seoDescription"],
  blogTag: ["name", "description"],
  banner: ["title", "description", "buttonText"],
  slider: ["title", "description", "buttonText"],
  fomo: ["notificationMessage"],
  notification: ["title", "message"],
  coupon: ["description"],
  country: ["content.preheaderMessage", "contacts.address"],
  homeContentBlock: ["title", "description", "quote", "badge", "message", "contactAddress"],
  // Small shared catalog dictionaries used across products (filters,
  // variant options) — translating just "name" covers what shoppers see;
  // an attribute's `values` array (e.g. Size: Small/Medium/Large) isn't
  // translated yet — the generic field-translation system handles simple
  // string/dot-path fields, not array elements.
  tag: ["name"],
  attribute: ["name"],
  color: ["name"],
};

// PHASE 6: SitePage (`page` entityType) content is a free-form, admin-grown
// dictionary rather than a fixed field list (that's the whole point of the
// CMS being "dynamic" — editors add new keys without a deploy). So instead
// of a static TRANSLATABLE_FIELDS list, walk the document's `content` object
// and its `seo` block and translate every string it finds (recursing into
// arrays/objects for list-style content like FAQ items or table rows).
// A handful of keys are deliberately left alone — they're configuration,
// not copy, and running them through MT would corrupt them.
const PAGE_NON_TRANSLATABLE_KEYS = new Set([
  "icon", "iconKey", "color", "image", "img", "src", "href", "link", "url",
  "id", "_id", "key", "slug", "type", "order", "phone", "whatsapp", "email",
  "embedUrl", "mapEmbedUrl", "countryCode", "lat", "lng", "rating",
  // Structural/config values that happen to be strings but aren't copy:
  // stat counts ("797+"), i18n key references ("statCustomers"), step
  // numerals ("1", "2", ...), and internal filter taxonomy ("ordering",
  // "shipping", ...) on FAQ items. Translating these produced garbage
  // (e.g. "statStates" and "797+" being sent to the MT API as if they
  // were sentences).
  "number", "labelKey", "step", "category",
]);

function isPlainObject(v) {
  return v && typeof v === "object" && !Array.isArray(v);
}

/**
 * Recursively collect translatable string leaves found under `node`,
 * skipping configuration-only keys, in a stable, repeatable order.
 */
function collectPageStrings(node, keyName, out) {
  if (node == null) return;
  if (typeof node === "string") {
    if (node.trim() && !PAGE_NON_TRANSLATABLE_KEYS.has(keyName)) {
      out.push(node);
    }
    return;
  }
  if (Array.isArray(node)) {
    node.forEach((item) => collectPageStrings(item, keyName, out));
    return;
  }
  if (isPlainObject(node)) {
    for (const [k, v] of Object.entries(node)) {
      collectPageStrings(v, k, out);
    }
  }
}

/**
 * Rebuild a deep clone of `node`, replacing translatable string leaves with
 * the next value from `translatedQueue` (consumed in the exact same order
 * collectPageStrings produced them — the two walks must stay in lockstep).
 */
function applyPageStrings(node, keyName, translatedQueue) {
  if (node == null) return node;
  if (typeof node === "string") {
    if (node.trim() && !PAGE_NON_TRANSLATABLE_KEYS.has(keyName)) {
      const next = translatedQueue.shift();
      return next !== undefined ? next : node;
    }
    return node;
  }
  if (Array.isArray(node)) {
    return node.map((item) => applyPageStrings(item, keyName, translatedQueue));
  }
  if (isPlainObject(node)) {
    const out = {};
    for (const [k, v] of Object.entries(node)) {
      out[k] = applyPageStrings(v, k, translatedQueue);
    }
    return out;
  }
  return node;
}

/**
 * Translate an entire SitePage's `content` (+ `seo`) dictionary into every
 * target language and persist to the Translation collection, honoring the
 * same "don't clobber a human's manual edits" guard as translateEntity().
 *
 * @param {{ entityId: string, document: { content: object, seo?: object }, sourceLang?: string, targetLangs?: string[] }} opts
 */
export async function translateSitePage({ entityId, document, sourceLang = "en", targetLangs }) {
  const sourceTree = { content: document.content || {}, seo: document.seo || {} };
  const strings = [];
  collectPageStrings(sourceTree, "", strings);
  if (strings.length === 0) return;

  const targetLanguages = (targetLangs && targetLangs.length ? targetLangs : SUPPORTED_LANGUAGES).filter(
    (l) => l !== sourceLang
  );

  for (const targetLang of targetLanguages) {
    try {
      const existing = await TranslationModel.findOne({
        entityType: "page",
        entityId,
        language: targetLang,
      }).lean();

      // A human has reviewed/edited this language for this page already —
      // never silently overwrite their work with a fresh machine pass.
      if (existing && existing.autoTranslated === false) {
        console.log(`[translationService] Skipped page:${entityId} → ${targetLang} (manually reviewed)`);
        continue;
      }

      const translatedFlat = await translateBatch(strings, sourceLang, targetLang);
      const queue = [...translatedFlat];
      const translatedTree = applyPageStrings(sourceTree, "", queue);

      await TranslationModel.findOneAndUpdate(
        { entityType: "page", entityId, language: targetLang },
        {
          fields: { content: translatedTree.content, seo: translatedTree.seo },
          autoTranslated: true,
          translatedAt: new Date(),
          engine: "openai",
          sourceLanguage: sourceLang,
        },
        { upsert: true, new: true }
      );
      console.log(`[translationService] Translated page:${entityId} → ${targetLang}`);
    } catch (err) {
      console.error(`[translationService] Error translating page:${entityId} → ${targetLang}:`, err.message);
    }
  }
}

// ── Core translation ─────────────────────────────────────────────────────────

/**
 * Translate a single string from sourceLang to targetLang.
 *
 * @param {string} text
 * @param {string} sourceLang  e.g. "en"
 * @param {string} targetLang  e.g. "fr"
 * @returns {Promise<string>}
 */
/**
 * Translate a single string via OpenAI. Non-fatal on failure — returns the
 * source text back so callers never have to special-case errors.
 */
export async function translateText(text, sourceLang = "en", targetLang = "fr") {
  if (!text || typeof text !== "string" || text.trim() === "") return text;
  if (sourceLang === targetLang) return text;
  return translateOneAI(text, sourceLang, targetLang);
}

/**
 * Translate multiple strings via OpenAI, in as few requests as practical.
 * Order-preserving; any string that fails after retries falls back to its
 * source value rather than failing the whole batch (see
 * services/ai/openaiTranslationClient.js for chunking/retry/cache details).
 *
 * @param {string[]} texts
 * @param {string} sourceLang
 * @param {string} targetLang
 * @returns {Promise<string[]>}
 */
export async function translateBatch(texts, sourceLang = "en", targetLang = "fr") {
  if (!texts || texts.length === 0) return texts;
  if (sourceLang === targetLang) return texts;
  return translateBatchAI(texts, sourceLang, targetLang);
}

// ── Entity translation ────────────────────────────────────────────────────────

/**
 * Extract translatable field values from a document object.
 *
 * @param {object} doc     Mongoose document or plain object
 * @param {string[]} fields  e.g. ["name", "description", "seo.title"]
 * @returns {{ key: string, value: string }[]}
 */
function extractFields(doc, fields) {
  const result = [];
  for (const field of fields) {
    const parts = field.split(".");
    let value = doc;
    for (const part of parts) {
      value = value?.[part];
    }
    if (value && typeof value === "string") {
      result.push({ key: field, value });
    }
  }
  return result;
}

/**
 * Translate all translatable fields of an entity into all supported languages
 * and persist the results to the Translation collection.
 *
 * Called after create/update in admin controllers.
 *
 * @param {{
 *   entityType: string,
 *   entityId: string | import('mongoose').ObjectId,
 *   document: object,
 *   sourceLang?: string,
 * }} options
 */
export async function translateEntity({
  entityType,
  entityId,
  document,
  sourceLang = "en",
}) {
  const fields = TRANSLATABLE_FIELDS[entityType];
  if (!fields) {
    console.warn(
      `[translationService] No fields config for entityType: ${entityType}`,
    );
    return;
  }

  const extracted = extractFields(document, fields);
  if (extracted.length === 0) return;

  const targetLanguages = SUPPORTED_LANGUAGES.filter((l) => l !== sourceLang);

  for (const targetLang of targetLanguages) {
    try {
      // ── Guard: never overwrite fields a human has manually edited ─────────
      // Check for an existing doc where autoTranslated === false (human-edited).
      // For those fields we skip auto-translation entirely so foreign-admin
      // copy is preserved even when the Nigerian team updates the source content.
      const existing = await TranslationModel.findOne({
        entityType,
        entityId,
        language: targetLang,
      }).lean();

      // Determine which fields are safe to auto-translate:
      // - If no existing doc → translate everything
      // - If existing doc with autoTranslated === false → skip fields that
      //   are already in existing.fields (human-reviewed); translate the rest
      // - If existing doc with autoTranslated === true  → re-translate all
      //   (source content changed; no human edits to protect)
      const manualFields =
        existing && existing.autoTranslated === false
          ? Object.keys(existing.fields || {})
          : [];

      const fieldsToTranslate =
        manualFields.length > 0
          ? extracted.filter((e) => !manualFields.includes(e.key))
          : extracted;

      if (fieldsToTranslate.length === 0) {
        console.log(
          `[translationService] Skipped ${entityType}:${entityId} → ${targetLang} (all fields manually edited)`,
        );
        continue;
      }

      const texts = fieldsToTranslate.map((e) => e.value);
      const translated = await translateBatch(texts, sourceLang, targetLang);

      // Merge new auto-translations on top of any existing manual fields
      const translatedFields = { ...(existing?.fields || {}) };
      fieldsToTranslate.forEach((entry, idx) => {
        translatedFields[entry.key] = translated[idx];
      });

      // autoTranslated stays false if there are still manually-edited fields
      const hasManualFields = manualFields.length > 0;

      // Upsert: replace if already exists
      await TranslationModel.findOneAndUpdate(
        { entityType, entityId, language: targetLang },
        {
          fields: translatedFields,
          autoTranslated: !hasManualFields,
          translatedAt: new Date(),
          engine: hasManualFields ? "mixed" : "openai",
        },
        { upsert: true, new: true },
      );

      console.log(
        `[translationService] Translated ${entityType}:${entityId} → ${targetLang}`,
      );
    } catch (err) {
      console.error(
        `[translationService] Error translating ${entityType}:${entityId} → ${targetLang}:`,
        err.message,
      );
    }
  }
}

// ── Retrieval ─────────────────────────────────────────────────────────────────

/**
 * Get a stored translation for a single entity.
 *
 * @param {string} entityType
 * @param {string | ObjectId} entityId
 * @param {string} language
 * @returns {Promise<object|null>}  The `fields` map or null
 */
export async function getTranslation(entityType, entityId, language) {
  if (language === "en") return null; // English is the source — no translation needed

  const doc = await TranslationModel.findOne({
    entityType,
    entityId,
    language,
  }).lean();

  return doc ? doc.fields : null;
}

/**
 * Merge translation fields into a document object.
 * Mutates a shallow copy — original is not modified.
 *
 * @param {object} doc         The source document (plain object)
 * @param {object|null} fields The translation fields map
 * @returns {object}
 */
export function applyTranslation(doc, fields) {
  if (!fields || Object.keys(fields).length === 0) return doc;

  const result = { ...doc };
  for (const [key, value] of Object.entries(fields)) {
    const parts = key.split(".");
    if (parts.length === 1) {
      result[key] = value;
    } else {
      // Shallow nested merge (seo.title, seo.description)
      const parent = parts[0];
      if (!result[parent]) result[parent] = {};
      else result[parent] = { ...result[parent] };
      result[parent][parts[1]] = value;
    }
  }
  return result;
}

/**
 * Convenience: fetch translations for a list of entity IDs.
 *
 * @param {string} entityType
 * @param {string[]} entityIds
 * @param {string} language
 * @returns {Promise<Map<string, object>>}  entityId → fields
 */
export async function getBulkTranslations(entityType, entityIds, language) {
  if (language === "en" || !entityIds?.length) return new Map();

  const docs = await TranslationModel.find({
    entityType,
    entityId: { $in: entityIds },
    language,
  }).lean();

  const map = new Map();
  for (const doc of docs) {
    map.set(doc.entityId.toString(), doc.fields);
  }
  return map;
}

/**
 * PHASE 5: localize a list of documents in one shot.
 *
 * Bulk-fetches translations for the given language and merges them into each
 * doc with per-field fallback to the source (master) value — a field missing a
 * translation keeps its master text rather than disappearing.
 *
 * @param {string} entityType
 * @param {object[]} docs        plain objects (use .lean() or .toObject())
 * @param {string} language      target language ("en" is a no-op passthrough)
 * @param {object} [opts]
 * @param {(d:object)=>string} [opts.idOf]  how to read each doc's id
 * @returns {Promise<object[]>}  localized copies (originals untouched)
 */
export async function localizeList(entityType, docs, language, opts = {}) {
  if (!Array.isArray(docs) || !docs.length) return docs || [];
  if (!language || language === "en") return docs;

  const idOf = opts.idOf || ((d) => (d._id || d.id)?.toString());
  const ids = docs.map(idOf).filter(Boolean);
  const map = await getBulkTranslations(entityType, ids, language);
  if (map.size === 0) return docs;

  return docs.map((d) => {
    const fields = map.get(idOf(d));
    return fields ? applyTranslation(d, fields) : d;
  });
}

/**
 * PHASE 5: localize a single document with per-field fallback to master.
 */
export async function localizeOne(entityType, doc, language) {
  if (!doc || !language || language === "en") return doc;
  const id = (doc._id || doc.id)?.toString();
  if (!id) return doc;
  const fields = await getTranslation(entityType, id, language);
  return fields ? applyTranslation(doc, fields) : doc;
}
