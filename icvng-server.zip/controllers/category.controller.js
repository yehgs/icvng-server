import CategoryModel from "../models/category.model.js";
import SubCategoryModel from "../models/subCategory.model.js";
import ProductModel from "../models/product.model.js";
import generateSlug from "../utils/generateSlug.js";
import { translateEntity, getBulkTranslations, applyTranslation } from "../utils/translationService.js";

export const AddCategoryController = async (request, response) => {
  try {
    const { name, image, slug } = request.body;

    if (request.user?.subRole === "GRAPHICS") {
      return response.status(403).json({
        message: "Graphics/Designer accounts cannot create categories — image updates to existing categories only.",
        error: true,
        success: false,
      });
    }

    if (!name) {
      return response.status(400).json({
        message: "Category name is required",
        error: true,
        success: false,
      });
    }

    // Generate slug if not provided
    const generatedSlug = slug || generateSlug(name);

    // Check for existing slug to ensure uniqueness
    const existingCategory = await CategoryModel.findOne({
      slug: generatedSlug,
    });
    if (existingCategory) {
      return response.status(400).json({
        message: "A category with this slug already exists",
        error: true,
        success: false,
      });
    }

    const addCategory = new CategoryModel({
      name,
      image: image || "",
      slug: generatedSlug,
    });

    const saveCategory = await addCategory.save();

    if (!saveCategory) {
      return response.status(500).json({
        message: "Category could not be created",
        error: true,
        success: false,
      });
    }

    // Auto-translate to all non-English languages. Awaited (was
    // fire-and-forget) so a real failure isn't silently swallowed.
    try {
      await translateEntity({
        entityType: "category",
        entityId: saveCategory._id,
        document: saveCategory.toObject(),
      });
    } catch (err) {
      console.error("[translate] category create:", err.message);
    }

    return response.json({
      message: "Category Added Successfully",
      data: saveCategory,
      success: true,
      error: false,
    });
  } catch (error) {
    return response.status(500).json({
      message: error.message || error,
      error: true,
      success: false,
    });
  }
};

export const getCategoryController = async (request, response) => {
  try {
    const data = await CategoryModel.find().sort({ createdAt: -1 });

    // Localize into the active language (same mechanism as the category
    // mega-menu / category-structure endpoint) — this plain list feeds the
    // homepage "Shop by Category" filter carousel, which was bypassing
    // localization entirely by calling this endpoint instead.
    const language =
      (request.headers["x-language"] || "").toLowerCase() ||
      request.country?.language?.default ||
      "en";

    let localizedData = data;
    if (language !== "en") {
      const ids = data.map((c) => c._id.toString());
      const fieldsByCategory = await getBulkTranslations("category", ids, language);
      localizedData = data.map((cat) => {
        const fields = fieldsByCategory.get(cat._id.toString());
        return fields ? applyTranslation(cat.toObject(), fields) : cat;
      });
    }

    return response.json({
      data: localizedData,
      error: false,
      success: true,
    });
  } catch (error) {
    return response.status(500).json({
      message: error.message || error,
      error: true,
      success: false,
    });
  }
};

export const updateCategoryController = async (request, response) => {
  try {
    const { _id, name, image, slug } = request.body;

    // If name is provided, generate a new slug
    const updateData = {
      ...(name && { name }),
      ...(image && { image }),
      ...(name && { slug: generateSlug(name) }),
      ...(slug && { slug: generateSlug(slug) }),
    };

    // GRAPHICS: image-only (see brand.controller.js's
    // updateBrandController for the same pattern).
    if (request.user?.subRole === "GRAPHICS") {
      if (updateData.name) delete updateData.name;
      if (updateData.slug) delete updateData.slug;
    }

    // Check for existing slug to ensure uniqueness if a new slug is being set
    if (updateData.slug) {
      const existingCategory = await CategoryModel.findOne({
        slug: updateData.slug,
        _id: { $ne: _id },
      });

      if (existingCategory) {
        return response.status(400).json({
          message: "A category with this slug already exists",
          error: true,
          success: false,
        });
      }
    }

    const update = await CategoryModel.updateOne({ _id: _id }, updateData);

    // Auto-translate to all non-English languages — only worth triggering
    // if the translatable field (name) actually changed. Awaited (was
    // fire-and-forget) so a real failure isn't silently swallowed.
    if (updateData.name) {
      try {
        await translateEntity({
          entityType: "category",
          entityId: _id,
          document: { name: updateData.name },
        });
      } catch (err) {
        console.error("[translate] category update:", err.message);
      }
    }

    return response.json({
      message: "Category Updated Successfully",
      success: true,
      error: false,
      data: update,
    });
  } catch (error) {
    return response.status(500).json({
      message: error.message || error,
      error: true,
      success: false,
    });
  }
};

export const deleteCategoryController = async (request, response) => {
  try {
    const { _id } = request.body;

    if (request.user?.subRole === "GRAPHICS") {
      return response.status(403).json({
        message: "Graphics/Designer accounts cannot delete categories.",
        error: true,
        success: false,
      });
    }

    const checkSubCategory = await SubCategoryModel.find({
      category: {
        $in: [_id],
      },
    }).countDocuments();

    const checkProduct = await ProductModel.find({
      category: {
        $in: [_id],
      },
    }).countDocuments();

    if (checkSubCategory > 0 || checkProduct > 0) {
      return response.status(400).json({
        message: "Category is already use can't delete",
        error: true,
        success: false,
      });
    }

    const deleteCategory = await CategoryModel.deleteOne({ _id: _id });

    return response.json({
      message: "Delete category successfully",
      data: deleteCategory,
      error: false,
      success: true,
    });
  } catch (error) {
    return response.status(500).json({
      message: error.message || error,
      success: false,
      error: true,
    });
  }
};
