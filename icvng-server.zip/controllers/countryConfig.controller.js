/**
 * controllers/countryConfig.controller.js
 *
 * Exposes read-only country configuration to the frontend.
 * The client calls GET /api/country/config on startup and uses the
 * response to configure currency formatting, language, payment UI, etc.
 */

import {
  COUNTRY_CONFIG,
  ALL_COUNTRY_CODES,
  getCountryByCode,
} from "../config/countries/index.js";
import { getPublicPaymentInfo } from "../config/paymentRouter.js";
import { localizeOne } from "../utils/translationService.js";

/**
 * GET /api/country/config
 *
 * Returns the configuration for the domain the request came from.
 * The countryDetect middleware has already set req.countryCode.
 */
export async function getCountryConfig(req, res) {
  try {
    const country = req.country;
    const payment = getPublicPaymentInfo(req.countryCode);

    // Preheader message + contact address are content-managed per country
    // (Admin → Settings → Countries) and editable per language (Admin →
    // Translations → Countries) — localize them here so the storefront on
    // e.g. i-coffee.tg shows the French copy without any client-side fetch.
    const language =
      (req.headers["x-language"] || "").toLowerCase() ||
      country.language?.default ||
      "en";
    const localizedCountry = await localizeOne("country", country, language);

    return res.json({
      success: true,
      error: false,
      data: {
        _id: localizedCountry._id,
        code: localizedCountry.code,
        name: localizedCountry.name,
        domain: localizedCountry.domain,
        currency: localizedCountry.currency,
        language: localizedCountry.language,
        timezone: localizedCountry.timezone,
        phonePrefix: localizedCountry.phonePrefix,
        flagEmoji: localizedCountry.flagEmoji,
        seo: localizedCountry.seo,
        payment,
        // Content-managed via the admin panel (Settings → Countries): the
        // header preheader message and the footer contact details are
        // editable per market and reflect immediately on the domain that
        // country serves — no static text, no deploy.
        contacts: localizedCountry.contacts || {},
        content: localizedCountry.content || {},
        tawk: localizedCountry.tawk || {},
      },
    });
  } catch (err) {
    console.error("getCountryConfig error:", err);
    return res.status(500).json({
      success: false,
      error: true,
      message: "Could not load country configuration",
    });
  }
}

/**
 * GET /api/country/all
 *
 * Returns a public-safe list of all active countries.
 * Used by the country-switcher UI on the frontend.
 */
export async function getAllCountries(req, res) {
  try {
    const countries = ALL_COUNTRY_CODES.map((code) => {
      const c = COUNTRY_CONFIG[code];
      return {
        code: c.code,
        name: c.name,
        domain: c.domain,
        // adminDomain is what the admin panel's AdminCountryContext
        // matches window.location.hostname against (e.g. app.i-coffee.tg).
        // seo.siteName drives the "I-COFFEE.XX" brand line on the login
        // screen. Both were missing here, so the admin frontend could
        // never resolve a non-Nigeria hostname and always fell back to
        // the NG defaults.
        adminDomain: c.adminDomain,
        seo: c.seo,
        currency: c.currency,
        language: c.language,
        flagEmoji: c.flagEmoji,
      };
    });

    return res.json({
      success: true,
      error: false,
      data: countries,
    });
  } catch (err) {
    console.error("getAllCountries error:", err);
    return res.status(500).json({
      success: false,
      error: true,
      message: "Could not load countries",
    });
  }
}

/**
 * GET /api/country/detect
 *
 * Called by the frontend to get country suggestion based on IP/domain.
 * Returns the currently detected country so the client can show
 * a "switch domain?" popup if the user's locale differs.
 */
export async function detectUserCountry(req, res) {
  try {
    const detectedCountry = req.country;

    // Optionally read Accept-Language header for a language hint
    const acceptLanguage = req.headers["accept-language"] || "";
    const preferredLang = acceptLanguage.split(",")[0].split("-")[0].toLowerCase();

    return res.json({
      success: true,
      error: false,
      data: {
        detectedCountry: {
          code: detectedCountry.code,
          name: detectedCountry.name,
          domain: detectedCountry.domain,
          flagEmoji: detectedCountry.flagEmoji,
          currency: detectedCountry.currency,
        },
        preferredLanguage: preferredLang || detectedCountry.language.default,
      },
    });
  } catch (err) {
    console.error("detectUserCountry error:", err);
    return res.status(500).json({
      success: false,
      error: true,
      message: "Could not detect country",
    });
  }
}
