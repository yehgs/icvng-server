// route/blog.route.js
import { Router } from 'express';
import {
  createBlogCategoryController,
  getBlogCategoriesController,
  getBlogCategoryController,
  updateBlogCategoryController,
  deleteBlogCategoryController,
  getPublicBlogCategoriesController,
} from '../controllers/blogCategory.controller.js';
import {
  createBlogTagController,
  getBlogTagsController,
  getBlogTagController,
  updateBlogTagController,
  deleteBlogTagController,
  getPublicBlogTagsController,
} from '../controllers/blogTag.controller.js';
import {
  createBlogPostController,
  getBlogPostsController,
  getBlogPostController,
  updateBlogPostController,
  deleteBlogPostController,
  getPublicBlogPostsController,
  getBlogPostBySlugController,
  getFeaturedBlogPostsController,
  getRelatedBlogPostsController,
  toggleFeaturedBlogPostController,
} from '../controllers/blogPost.controller.js';
import auth from '../middleware/auth.js';
import blogAuth from '../middleware/blogAuth.js';
import { countryScope } from '../middleware/countryScope.js';

const blogRouter = Router();

// Public routes (no authentication needed)
blogRouter.get('/public/categories', getPublicBlogCategoriesController);
blogRouter.get('/public/tags', getPublicBlogTagsController);
blogRouter.get('/public/posts', getPublicBlogPostsController);
blogRouter.get('/public/posts/featured', getFeaturedBlogPostsController);
blogRouter.get('/public/posts/slug/:slug', getBlogPostBySlugController);
blogRouter.get('/public/posts/:id/related', getRelatedBlogPostsController);

// Admin routes (authentication + admin role required)
// Blog Categories
blogRouter.post(
  '/admin/categories',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  createBlogCategoryController
);
blogRouter.get(
  '/admin/categories',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  getBlogCategoriesController
);
blogRouter.get(
  '/admin/categories/:id',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  getBlogCategoryController
);
blogRouter.put(
  '/admin/categories/:id',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  updateBlogCategoryController
);
blogRouter.delete(
  '/admin/categories/:id',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  deleteBlogCategoryController
);

// Blog Tags
blogRouter.post(
  '/admin/tags',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  createBlogTagController
);
blogRouter.get(
  '/admin/tags',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  getBlogTagsController
);
blogRouter.get(
  '/admin/tags/:id',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  getBlogTagController
);
blogRouter.put(
  '/admin/tags/:id',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  updateBlogTagController
);
blogRouter.delete(
  '/admin/tags/:id',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  deleteBlogTagController
);

// Blog Posts — countryScope activates per-country isolation: an editor
// assigned to a country only sees/edits that market's posts, and can
// translate + publish independently of HQ's English original. Categories
// and tags above stay global taxonomy shared across every market.
blogRouter.post(
  '/admin/posts',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  countryScope,
  createBlogPostController
);
blogRouter.get(
  '/admin/posts',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  countryScope,
  getBlogPostsController
);
blogRouter.get(
  '/admin/posts/:id',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  countryScope,
  getBlogPostController
);
blogRouter.put(
  '/admin/posts/:id',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  countryScope,
  updateBlogPostController
);
blogRouter.patch(
  '/admin/posts/:id/toggle-featured',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  countryScope,
  toggleFeaturedBlogPostController
);
blogRouter.delete(
  '/admin/posts/:id',
  auth,
  blogAuth(['EDITOR', 'IT', 'DIRECTOR', 'MANAGER']),
  countryScope,
  deleteBlogPostController
);

export default blogRouter;
