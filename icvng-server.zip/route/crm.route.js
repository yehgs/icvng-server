//server
// route/crm.route.js  (updated)
import { Router } from "express";
import auth from "../middleware/auth.js";
import adminAuth from "../middleware/adminAuth.js";
import { countryScope } from "../middleware/countryScope.js";
import {
  getCrmMetaController,
  getLeadsController,
  createLeadController,
  updateLeadController,
  moveLeadStageController,
  deleteLeadController,
  reviewDeleteRequestController,
  getDeleteRequestsController,
  addActivityController,
  bulkImportLeadsController,
  getCrmStatsController,
  downloadLeadsTemplateCSV,
  exportLeadsCSV,
  bulkImportLeadsCsvController,
} from "../controllers/crm-lead.controller.js";

const crmRouter = Router();
crmRouter.use(auth);
crmRouter.use(adminAuth);
crmRouter.use(countryScope); // populates req.countryScope — required for lead/stat filtering below

crmRouter.get("/meta", getCrmMetaController);
crmRouter.get("/stats", getCrmStatsController);
crmRouter.get("/leads", getLeadsController);
crmRouter.get("/leads/template/csv", downloadLeadsTemplateCSV);
crmRouter.get("/leads/export/csv", exportLeadsCSV);
crmRouter.get("/delete-requests", getDeleteRequestsController);
crmRouter.post("/leads", createLeadController);
crmRouter.post("/leads/bulk-import", bulkImportLeadsController);
crmRouter.post("/leads/import/csv", bulkImportLeadsCsvController);
crmRouter.put("/leads/:id", updateLeadController);
crmRouter.put("/leads/:id/stage", moveLeadStageController);
crmRouter.delete("/leads/:id", deleteLeadController); // body: { reason } for non-IT/Director
crmRouter.put("/leads/:id/delete-request", reviewDeleteRequestController); // body: { action: 'approve'|'reject', reviewNote }
crmRouter.post("/leads/:id/activity", addActivityController);

export default crmRouter;
