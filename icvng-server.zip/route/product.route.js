import { Router } from "express";
import auth from "../middleware/auth.js";
import {
  createProductController,
  searchProductController,
  getCategoryStructureController,
  deleteProductDetails,
  getProductByCategory,
  getProductByCategoryAndSubCategory,
  getProductByBrand,
  getProductController,
  getProductDetails,
  searchProduct,
  searchProductAdmin,
  updateProductDetails,
  getFeaturedProducts,
  getLimitedEditionProducts,
  getProductsByAvailability,
  getProductBySKU,
  getProductControllerAdmin,
  getPopularProducts,
} from "../controllers/product.controller.js";
import { admin } from "../middleware/Admin.js";
import { countryScope } from "../middleware/countryScope.js";

const productRouter = Router();

// Create product
productRouter.post("/create", auth, admin, createProductController);

// Get products
productRouter.get("/search", searchProductController);
productRouter.get("/category-structure", getCategoryStructureController);
productRouter.post("/get", getProductController);
productRouter.post("/get-admin", auth, admin, countryScope, getProductControllerAdmin);
productRouter.post("/get-product-by-category", getProductByCategory);
productRouter.post(
  "/get-product-by-category-and-subcategory",
  getProductByCategoryAndSubCategory
);
productRouter.post("/get-product-details", getProductDetails);

// Update product
productRouter.put("/update-product-details", auth, admin, countryScope, updateProductDetails);

// Delete product
productRouter.delete("/delete-product", auth, admin, deleteProductDetails);

// Search product
productRouter.post("/search-product", searchProduct);
productRouter.post("/search-product-admin", searchProductAdmin);

// Filter products by category
productRouter.post("/get-product-by-category", getProductByCategory);

// Filter products by category and subcategory
productRouter.post(
  "/get-product-by-category-and-subcategory",
  getProductByCategoryAndSubCategory
);

// Filter products by brand
productRouter.post("/get-product-by-brand", getProductByBrand);

// Get featured products
productRouter.post("/get-featured-products", getFeaturedProducts);
productRouter.post("/get-limited-edition-products", getLimitedEditionProducts);

// Get products by availability status
productRouter.post("/get-products-by-availability", getProductsByAvailability);

// Get product by SKU
productRouter.post("/get-product-by-sku", getProductBySKU);

// Get popular products
productRouter.post("/get-popular-products", getPopularProducts);

export default productRouter;
